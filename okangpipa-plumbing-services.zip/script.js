/**
 * Okangpipa Plumbing Services - Interactive Features (Vanilla JavaScript)
 * Handles mobile drawer, dropdowns, counter animation, appointment modal,
 * video tour modal, gallery lightbox, and smooth scrolling.
 */

document.addEventListener('DOMContentLoaded', () => {
  // -------------------------------------------------------------------------
  // 1. Mobile Navigation Drawer
  // -------------------------------------------------------------------------
  const mobileToggleBtn = document.getElementById('mobileToggleBtn');
  const mobileNavDrawer = document.getElementById('mobileNavDrawer');
  const mobileNavClose = document.getElementById('mobileNavClose');
  const mobileLinks = document.querySelectorAll('.mobile-nav-link:not(.has-sub)');

  function openMobileNav() {
    mobileNavDrawer?.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeMobileNav() {
    mobileNavDrawer?.classList.remove('active');
    document.body.style.overflow = '';
  }

  mobileToggleBtn?.addEventListener('click', openMobileNav);
  mobileNavClose?.addEventListener('click', closeMobileNav);

  // Close when clicking outside drawer panel
  mobileNavDrawer?.addEventListener('click', (e) => {
    if (e.target === mobileNavDrawer) {
      closeMobileNav();
    }
  });

  mobileLinks.forEach((link) => {
    link.addEventListener('click', closeMobileNav);
  });

  // Mobile Accordions
  const mobileAccordionTriggers = document.querySelectorAll('.mobile-nav-link.has-sub');
  mobileAccordionTriggers.forEach((trigger) => {
    trigger.addEventListener('click', (e) => {
      e.preventDefault();
      const subnav = trigger.nextElementSibling;
      const chevron = trigger.querySelector('.chevron-icon');
      if (subnav) {
        subnav.classList.toggle('open');
        if (chevron) {
          chevron.style.transform = subnav.classList.contains('open') ? 'rotate(180deg)' : 'rotate(0deg)';
        }
      }
    });
  });

  // -------------------------------------------------------------------------
  // 2. Animated Counter for "2,650 + Projects Completed"
  // -------------------------------------------------------------------------
  const counterElement = document.getElementById('projectCounter');
  let hasAnimatedCounter = false;

  function animateCounter(el, target, duration = 1800) {
    let startTimestamp = null;
    const startValue = 0;
    
    function step(timestamp) {
      if (!startTimestamp) startTimestamp = timestamp;
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      // Ease out cubic
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      const currentValue = Math.floor(easeProgress * (target - startValue) + startValue);
      el.textContent = currentValue.toLocaleString('en-US');
      
      if (progress < 1) {
        window.requestAnimationFrame(step);
      } else {
        el.textContent = target.toLocaleString('en-US');
      }
    }
    
    window.requestAnimationFrame(step);
  }

  // Use Intersection Observer for counter
  if (counterElement) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting && !hasAnimatedCounter) {
          hasAnimatedCounter = true;
          animateCounter(counterElement, 2650, 1600);
        }
      });
    }, { threshold: 0.3 });

    observer.observe(counterElement);
  }

  // -------------------------------------------------------------------------
  // 3. Modals System (Appointment, Video Tour, Lightbox)
  // -------------------------------------------------------------------------
  const appointmentModal = document.getElementById('appointmentModal');
  const appointmentClose = document.getElementById('appointmentClose');
  const appointmentBtns = document.querySelectorAll('[data-action="appointment"]');

  const videoModal = document.getElementById('videoModal');
  const videoClose = document.getElementById('videoClose');
  const watchVideoBtn = document.getElementById('watchVideoBtn');
  const videoFrame = document.getElementById('tourVideoFrame');

  const lightboxModal = document.getElementById('lightboxModal');
  const lightboxClose = document.getElementById('lightboxClose');
  const lightboxImg = document.getElementById('lightboxImg');
  const lightboxTitle = document.getElementById('lightboxTitle');
  const galleryCards = document.querySelectorAll('.gallery-card');

  // Open Appointment Modal
  function openAppointmentModal() {
    closeMobileNav();
    appointmentModal?.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeAppointmentModal() {
    appointmentModal?.classList.remove('active');
    document.body.style.overflow = '';
  }

  appointmentBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openAppointmentModal();
    });
  });

  appointmentClose?.addEventListener('click', closeAppointmentModal);
  appointmentModal?.addEventListener('click', (e) => {
    if (e.target === appointmentModal) closeAppointmentModal();
  });

  // Open Video Tour Modal
  function openVideoModal() {
    videoModal?.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeVideoModal() {
    videoModal?.classList.remove('active');
    document.body.style.overflow = '';
    // Pause video if playing
    if (videoFrame && typeof videoFrame.pause === 'function') {
      videoFrame.pause();
    }
  }

  watchVideoBtn?.addEventListener('click', openVideoModal);
  videoClose?.addEventListener('click', closeVideoModal);
  videoModal?.addEventListener('click', (e) => {
    if (e.target === videoModal) closeVideoModal();
  });

  // Lightbox for Expertise Gallery
  const galleryData = [
    {
      title: "Drainage Trap & Pipe Restoration",
      src: "/assets/images/expertise_1.jpg",
      desc: "Precision chrome trap replacement and leakage diagnosis under kitchen and bathroom sinks."
    },
    {
      title: "Modern Sink & Faucet Inspection",
      src: "/assets/images/expertise_2.jpg",
      desc: "Water pressure testing, fixture installation, and seamless kitchen supply line assembly."
    },
    {
      title: "Under-Counter Piping Remediation",
      src: "/assets/images/expertise_3.jpg",
      desc: "Emergency kitchen drain unclogging and copper supply line valve maintenance."
    }
  ];

  galleryCards.forEach((card, index) => {
    card.addEventListener('click', () => {
      const data = galleryData[index];
      if (data && lightboxImg && lightboxTitle) {
        lightboxImg.src = data.src;
        lightboxTitle.textContent = data.title;
        lightboxModal?.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  function closeLightbox() {
    lightboxModal?.classList.remove('active');
    document.body.style.overflow = '';
  }

  lightboxClose?.addEventListener('click', closeLightbox);
  lightboxModal?.addEventListener('click', (e) => {
    if (e.target === lightboxModal) closeLightbox();
  });

  // -------------------------------------------------------------------------
  // 4. Form Submissions & Toast Feedback
  // -------------------------------------------------------------------------
  const appointmentForm = document.getElementById('appointmentForm');
  const toastNotice = document.getElementById('toastNotice');
  const toastMessage = document.getElementById('toastMessage');

  function showToast(msg) {
    if (toastNotice && toastMessage) {
      toastMessage.textContent = msg;
      toastNotice.classList.add('show');
      setTimeout(() => {
        toastNotice.classList.remove('show');
      }, 4200);
    }
  }

  appointmentForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const nameInput = document.getElementById('bookingName');
    const name = nameInput ? nameInput.value : 'Customer';
    closeAppointmentModal();
    showToast(`Thank you, ${name}! Your appointment has been booked. Our master technician will call you shortly.`);
    appointmentForm.reset();
  });

  // -------------------------------------------------------------------------
  // 5. Global Escape Key Handler
  // -------------------------------------------------------------------------
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeAppointmentModal();
      closeVideoModal();
      closeLightbox();
      closeMobileNav();
    }
  });

  // -------------------------------------------------------------------------
  // 6. Smooth Scrolling for Navigation
  // -------------------------------------------------------------------------
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId && targetId !== '#') {
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
          e.preventDefault();
          targetElement.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      }
    });
  });

  console.log("Okangpipa Plumbing Services homepage scripts loaded successfully.");
});
