# Okangpipa Plumbing Services - Website Project

A complete, production-grade responsive website developed according to the Okangpipa Plumbing Services homepage design specification.

## Technologies Used
- **HTML5**: Clean, semantic markup with accessible ARIA landmarks.
- **CSS3**: Modern layout using CSS Grid, Flexbox, custom design tokens, and smooth cubic-bezier transitions. Fully responsive across desktop, laptop, tablet, and mobile.
- **Vanilla JavaScript**: Zero-dependency interactive logic for mobile drawer navigation, multi-level dropdowns, animated odometer counters, appointment booking modal, video tour modal, and project lightbox.

## Project Structure
```
├── index.html                  # Main homepage markup
├── style.css                   # Complete stylesheet with responsive media queries
├── script.js                   # Interactive UI features and handlers
├── README.md                   # Project documentation and quick-start instructions
└── assets/
    └── images/
        ├── logo.png            # Official Kangpipa brand logo
        ├── hero_bg.jpg         # Hero master plumber visual with utility valves
        ├── about_plumber.jpg   # Friendly technician portrait with wrench
        ├── expertise_1.jpg     # Drainage trap & P-pipe restoration photo
        ├── expertise_2.jpg     # Kitchen sink & faucet inspection photo
        ├── expertise_3.jpg     # Cabinet plumbing repair photo
        ├── partners.png        # Partner company logos strip
        └── pipes_texture.jpg   # Subtle industrial piping texture
```

## How to Run
1. Simply double-click `index.html` to open and test in any modern web browser (Chrome, Edge, Safari, Firefox).
2. Or serve via any local HTTP server:
   ```bash
   npx serve .
   # or
   python3 -m http.server 8000
   ```
3. Ready for 1-click deployment on Netlify, Vercel, GitHub Pages, or any static hosting provider.
